import yfinance as yf
import pandas as pd

def get_stock_data(ticker, start_date, end_date):
    try:
        # Download historical stock data
        stock_data = yf.download(ticker, start=start_date, end=end_date)
        return stock_data
    except Exception as e:
        print(f"Error fetching data for {ticker}: {e}")
        return None

# Example usage
ticker_symbol = "TSLA"  # Replace with the desired stock symbol
start_date = "2023-01-01"  # Replace with the desired start date (y-m-d)
end_date = "2024-01-01"    # Replace with the desired end date (y-m-d)

stock_data = get_stock_data(ticker_symbol, start_date, end_date)

# print(stock_data)

df = pd.DataFrame(stock_data) 
print(df)


# Save the dataframe to a CSV file
excel_file_path = 'stockdata.xlsx'
# df.to_csv('stock_data.csv', index=False)
df.to_excel(excel_file_path, index=False)

print(f"\nData Frame saved to {stock_data}")